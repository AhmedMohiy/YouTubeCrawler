import json
from urllib2 import urlopen, URLError, Request
from settings import *
from data import VideoData

# build url for the api to get channel videos
def build(url,key,part,order,max_result,channelid):
    url += 'key='+key+'&'+'channelId='+channelid+'&'+'part='+part+'&'+'order='+order+'&'+'maxResults='+max_result
    return url

# create set contains all videos of a channel
def get_all_videos(channel_id):
    key = function()
    url = 'https://www.googleapis.com/youtube/v3/search?'
    part = 'snippet,id'
    order = 'date'
    maxResults = '50'
    url = build(url,key,part,order,maxResults,channel_id)

    all_videos_id = set()

    res_string = get_page_videos(url,'')
    if len(res_string) > 0:
        response_json = json.loads(res_string)

        while True:
            for item in response_json['items']:
                if len(item) > 0 and item['id']['kind'] == 'youtube#video':
                    id = item['id']['videoId']
                    all_videos_id.add(str(id))
            if not 'nextPageToken' in response_json:
                break
            res_string = get_page_videos(url, response_json['nextPageToken'])
            response_json = json.loads(res_string)

    return all_videos_id








# Get one page of items from channel
def get_page_videos(url,page_token):
    if len(page_token) > 0:
        url += '&pageToken=' + page_token

    try:
        response = urlopen(url)
        response_bytes = response.read()
        response_string = response_bytes.decode("utf-8")
        return response_string
    except URLError:
        print 'error with connection'
        return ''




# Get video details
def get_video_details(video_id):
    key = function()

    url = 'https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails,statistics&id=' + video_id +'&key='+key
    response_json = ''
    try:
        response = urlopen(url)
        response_bytes = response.read()
        response_string = response_bytes.decode("utf-8")
        response_json = json.loads(response_string)
    except URLError:
        print 'error with connection'
        return ''

    data_object = json_to_video_object(response_json, video_id)
    return data_object


# convert json to VideoData object
def json_to_video_object(response_json, video_id):

    url = 'https://www.youtube.com/watch?v=' + video_id
    video_title = response_json['items'][0]['snippet']['title']
    duration = response_json['items'][0]['contentDetails']['duration']
    views = response_json['items'][0]['statistics']['viewCount']
    thumbnail_url = response_json['items'][0]['snippet']['thumbnails']['default']['url']
    if 'standard' in response_json['items'][0]['snippet']['thumbnails']:
        original_url = response_json['items'][0]['snippet']['thumbnails']['standard']['url']
    else:
        original_url = response_json['items'][0]['snippet']['thumbnails']['default']['url']

    thumbnail_local = download_image(thumbnail_url)
    original_local = download_image(original_url)

    data_object = VideoData(url, video_title, duration, views, thumbnail_url, original_url, thumbnail_local,
                            original_local)

    return data_object


# download image using url
def download_image(url):

    url_array = url.split('/')
    image_name = url_array[-2]+'_'+url_array[-1]
    f = open(PROJECT_NAME+'/images/'+image_name, 'wb')
    f.write(urlopen(url).read())
    f.close()
    return PROJECT_NAME+'/images/'+image_name











