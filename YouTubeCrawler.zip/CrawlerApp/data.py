

# Class witch contains each video's data

class VideoData():

    def __init__(self,url,video_title,duration,views,thumbnail_url,original_url,thumbnail_local,original_local):
        self.url = url
        self.video_title = video_title
        self.duration = duration
        self.views = views
        self.thumbnail_url = thumbnail_url
        self.original_url = original_url
        self.thumbnail_local = thumbnail_local
        self.original_local = original_local

    def __str__(self):
        return self.video_title
