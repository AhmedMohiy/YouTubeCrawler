from settings import *
from api_fetch import get_video_details


class Spider:

    # Class variables(shared among all instances)
    project_name = PROJECT_NAME
    queue_file = ''
    crawled_file = ''
    object_file = ''
    object_set = set()
    queue = set()
    crawled = set()

    def __init__(self, project_name):
        Spider.project_name = project_name
        Spider.queue_file = Spider.project_name + '/queue.txt'
        Spider.crawled_file = Spider.project_name + '/crawled.txt'
        Spider.object_file = Spider.project_name + '/objects.txt'
        self.boot()


    @staticmethod
    def boot():
        create_project_directory()
        create_files(Spider.project_name)
        Spider.queue = file_to_set(Spider.queue_file)
        #Spider.crawled = file_to_set(Spider.crawled_file)

    @staticmethod
    def crawl_video(thread_name, video_id):
        if video_id not in Spider.crawled:
            print(thread_name + ' Now Crawling video with id ' + video_id)
            print('Queue ' + str(len(Spider.queue)) + ' | Crawled ' + str(len(Spider.crawled)))
            Spider.add_to_object_queue(video_id)
            #Spider.queue.remove(video_id)
            Spider.crawled.add(video_id)
            #Spider.updat_files()

    @staticmethod
    def add_to_object_queue(video_id):
        if video_id in Spider.crawled:
            pass

        obj = get_video_details(video_id)
        if obj is None:
            print "empty"
        else:
            Spider.object_set.add(obj)






    @staticmethod
    def updat_files():
        set_to_file(Spider.queue_file, Spider.queue)
        set_to_file(Spider.crawled_file, Spider.crawled)




