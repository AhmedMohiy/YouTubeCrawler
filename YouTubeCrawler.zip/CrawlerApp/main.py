import threading
from Queue import Queue

from api_fetch import *
from html_finder import Finder
from spider import Spider





queue = Queue()
Spider(PROJECT_NAME)


#Create worker threads (will die when main exits)
def create_workers():
    for _ in range(NUMBER_OF_THREADS):
        T = threading.Thread(target=workon)
        T.daemon = True
        T.start()

#Do the next job in the queue
def workon():
    while True:
        video_id = queue.get()
        Spider.crawl_video(threading.current_thread().name, video_id)
        queue.task_done()



# Each queued id is a new job
def create_jobs():
    for id in file_to_set(QUEUE_FILE):
        queue.put(id)
    queue.join()
    Spider.updat_files()
    insert_into_database(Spider.object_set)






#get an html to crawl it
def get_html(url):
    html_string = ''
    try:
        r = urlopen(url)
        html_bytes = r.read()
        html_string = html_bytes.decode("utf-8")
    except:
        print('Error: can not crawl page')

    return html_string



# start the whole thing
def start_work(url,url_format):
    html_string = get_html(url)
    if len(html_string) > 0:
        finder = Finder(url_format)
        finder.feed(html_string)
        videos_id_set = set()

        if url_format == 'playlist':
            videos_id_set = finder.videos_id

        elif url_format == 'channel':
            videos_id_set = get_all_videos(finder.channel_id)

        video_list = set()

        for video_id in videos_id_set:
            video_url = 'https://www.youtube.com/watch?v='+video_id
            db_obj = VideosData.objects.filter(url=video_url)
            if db_obj.count() > 0 :
                continue
            video_list.add(video_id)

        set_to_file(QUEUE_FILE, video_list)

        if len(video_list) > 0:
            return True
        else:
            return False









