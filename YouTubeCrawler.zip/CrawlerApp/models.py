# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.db import models


class VideosData(models.Model):

    url = models.CharField(max_length=1000)
    video_title = models.CharField(max_length=500)
    duration = models.CharField(max_length=20)
    views = models.CharField(max_length=100)
    thumbnail_url = models.CharField(max_length=1000)
    original_url = models.CharField(max_length=1000)
    thumbnail_local = models.CharField(max_length=1000)
    original_local = models.CharField(max_length=1000)
    video_download_local = models.CharField(max_length=1000)
    is_downloaded = models.BooleanField(default=False)


    def __str__(self):
        return self.video_title+'[]'+self.url+'[]'+self.duration

