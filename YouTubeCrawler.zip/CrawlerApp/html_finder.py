from HTMLParser import HTMLParser


# This class crawl into link and get all videos id (playlist, channel)
class Finder(HTMLParser):

    playlist_class_attribute = 'yt-uix-scroller-scroll-unit '
    playlist_id_attribute = 'data-video-id'
    channel_class_attribute = 'itemprop'
    channel_content_attribute = 'content'
    channel_class_value = 'channelId'

    def __init__(self, link_type):
        HTMLParser.__init__(self)
        self.link_type = link_type
        self.channel_id = ''
        self.videos_id = set()


    def handle_starttag(self, tag, attrs):

        if self.link_type == 'playlist':
            if tag == 'li':
                for (attribute, value) in attrs:
                    if attribute == 'class' and Finder.playlist_class_attribute in value:
                        for (another_attrs, another_value) in attrs:
                            if another_attrs == Finder.playlist_id_attribute:
                                self.videos_id.add(another_value)


        elif self.link_type == 'channel':
            if tag == 'meta':
                for (attribute,value) in attrs:
                    if attribute == Finder.channel_class_attribute and value == Finder.channel_class_value:
                        for (attribute_1,value_1) in attrs:
                            if attribute_1 == Finder.channel_content_attribute:
                                self.channel_id = value_1


    def videos_id(self):
        return self.videos_id

    def error(self, message):
        pass


