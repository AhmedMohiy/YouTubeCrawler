import os
import re
from data import VideoData
from .models import VideosData



PROJECT_NAME = "YouTubeCrawler"
QUEUE_FILE = PROJECT_NAME + '/queue.txt'
CRAWLED_FILE = PROJECT_NAME + '/crawled.txt'
OBJECT_FILE = PROJECT_NAME + '/objects.txt'
NUMBER_OF_THREADS = 6

NEXT = 0
SIZE = 0



# create directory fro the website witch be crawl
def create_project_directory():
    if not os.path.exists(PROJECT_NAME):
        print('Create project: '+PROJECT_NAME)
        os.makedirs(PROJECT_NAME)
    if not os.path.exists(PROJECT_NAME+'/images'):
        os.makedirs(PROJECT_NAME+'/images')
    if not os.path.exists(PROJECT_NAME+'/videos'):
        os.makedirs(PROJECT_NAME+'/videos')




# Create files (queue , crawled , objects) if not created
def create_files(project_name):
    queue = project_name + '/queue.txt'
    crawled = project_name + '/crawled.txt'
    objects = project_name + '/objects.txt'

    if not os.path.isfile(queue):
        write_file(queue, '')
    if not os.path.isfile(crawled):
        write_file(crawled, '')
    if not os.path.isfile(objects):
        write_file(objects, '')

# Create a new file
def write_file(path, data):
    file = open(path,'w')
    file.write(data)
    file.close()

# Append to file
def append_to_file(path,data):
    with open(path, 'a') as file:
        file.write(data+'\n')


# Delete file contents
def delete_file_contents(path):
    with open(path, 'w'):
        pass


# read file and convert each line to set
def file_to_set(path):
    data_set = set()
    with open(path,'rt') as file:
        for line in file:
            data_set.add(line.replace('\n', ''))
    return data_set


# Convert each item in a set to be row in the file
def set_to_file(path, ids):
    delete_file_contents(path)
    for id in ids:
        append_to_file(path, id)

# Convert data object to file
def data_object_to_file(path, object_data_set):

    for object_data in object_data_set:
        url = 'url:' + object_data.url
        video_title = 'video_title:' + object_data.video_title
        duration = 'duration:' + object_data.duration
        views = 'views:' + object_data.views
        thumbnail = 'thumbnail_url:' + object_data.thumbnail_url
        original = 'original_url:' + object_data.original_url
        thumbnail_local = 'thumbnail_local:' + object_data.thumbnail_local
        original_local = 'original_local:' + object_data.original_local
        object_string = '{' + url + ',' + video_title + ',' + duration + ',' + views + ',' + thumbnail + ',' + original + ',' + thumbnail_local +','+original_local+ '}'

        append_to_file(path, object_string)





# Convert  each row in file to data object
def file_to_data_object(path):

    object_set = set()
    for row in file_to_set(path):
        row = row.replace('{', '')
        data_list = row.split(',')
        data_set = []
        for item in data_list:
            if 'url' in item:
                data = item.split(':')
                st = data[1] + ':' +data[2]
                data_set.append(st)
            else:
                data = item.split(':')
                data_set.append(data[1])

        object_data = VideoData(data_set[0], data_set[1], data_set[2], data_set[3], data_set[4], data_set[5],
                                data_set[6], data_set[7])

        object_set.add(object_data)

    return object_set


# getting the key
def function():
    return 'AIzaSyA9NO-Z9cnGPSKqIx8_5fSYyacxSVRlxa0'


# Check validity of the url
def check_url(url, url_type):
    if url_type == 'playlist':
        if re.match(r'https://www\.youtube\.com/watch\?v=([a-z0-9A-Z_]+)&list=([a-z09-AA-Z_]+)', url, re.M | re.I):
            return True
    elif url_type == 'channel':
        if re.match(r'https://www\.youtube\.com/user/',url,re.M|re.I) or re.match(r'https://www\.youtube\.com/channel/', url, re.M | re.I):
            return True

    return False



# write into database
def insert_into_database(object_set):
    for obj in object_set:
        sc = VideosData.objects.filter(url=obj.url)
        if sc.count() > 0:
            continue
        object_data = VideosData()
        object_data.url = obj.url
        object_data.video_title = obj.video_title
        object_data.duration = duration_format(obj.duration)
        object_data.views = obj.views
        object_data.thumbnail_url = obj.thumbnail_url
        object_data.thumbnail_local = obj.thumbnail_local
        object_data.original_url = obj.original_url
        object_data.original_local = obj.original_local
        object_data.video_download_local = ''

        object_data.save()


# erase files
def erase():
    delete_file_contents(QUEUE_FILE)
    delete_file_contents(CRAWLED_FILE)



# duration 'PT3M38S' format to 3:38
def duration_format(duration):
    time = duration
    t_index = time.index("T")
    if 'H' in duration:
        pass

    elif 'M' in duration:
        m_index = time.index('M')
        if 'S' in duration:
            s_index = time.index('S')
            time = duration[t_index+1:m_index] +':'+duration[m_index+1:s_index]
        else:
            time = duration[t_index+1:m_index]

    elif 'S' in duration:
        s_index = time.index('S')
        time = '0:'+ duration[t_index+1:s_index]

    return time




