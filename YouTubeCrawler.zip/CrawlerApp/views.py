# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import pafy
import getpass
from django.shortcuts import redirect
from django.shortcuts import render
from settings import *
from main import *

per_page = 30


# home page
def home(request):
    VideosData.objects.all().delete()


    error = ''
    return render(request, 'CrawlerApp/home.html',{'error': error})

# view page to view images
def view(request):
    global NEXT, SIZE
    all_objects = VideosData.objects.all()
    for ob in all_objects:
        print ob.original_url

    return render(request, 'CrawlerApp/view.html', {'all_objects': all_objects})

# open view page after crawling the url
def result(request):
    url = request.POST['url']
    check = request.POST['check']
    all_objects = set()
    if len(check) > 0:
        c = check_url(url, check)
        print c
        if c:
            create_project_directory()
            create_files(PROJECT_NAME)
            bool_check = start_work(url, check)
            print bool_check
            if bool_check:
                create_workers()
                create_jobs()
                erase()
                print 'Done'
            all_objects = VideosData.objects.all()

            return render(request, 'CrawlerApp/view.html', {'all_objects':all_objects})
    error = ''
    if len(check) <= 0:
        error = 'Please choose between (Channel OR PlayList)'

    if not c:
        error = 'Make sure to write a correct url for YouTube (PlayList or Channel) and choose the equivalent choice'

    return render(request, 'CrawlerApp/home.html', {'error': error})


# get video details  and view it in detail page
def details(request, video_id):
    video_details = VideosData.objects.get(pk=video_id)

    time = video_details.duration
    context = {
        'video_details': video_details,
        'time':time,
    }
    print video_details
    return render(request, 'CrawlerApp/details.html', context)



# this function download videa and save it in the local download directory
def download_video(request,video_id):
    video_details = VideosData.objects.get(pk=video_id)
    url = video_details.url
    video = pafy.new(url)
    streams = video.streams

    user_name = getpass.getuser()
    filename = streams[len(streams)/2].download(filepath='/home/'+user_name+'/Downloads')
    print filename
    video_details.is_downloaded = True
    video_details.video_download_local = '/home/'+user_name+'/Downloads'
    video_details.save()

    return redirect('CrawlerApp:details',video_id)















