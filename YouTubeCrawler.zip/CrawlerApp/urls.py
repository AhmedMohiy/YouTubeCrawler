from django.conf.urls import url

from . import views

app_name = 'CrawlerApp'

urlpatterns = [
    # /crawler/
    url(r'^$', views.home, name='home'),

    # /crawler/result/
    url(r'^result/$', views.result, name='result'),
    # /crawler/view/
    url(r'^view/$', views.view, name='view'),
    # /crawler/71/details/
    url(r'^(?P<video_id>[0-9]+)/details/$', views.details, name='details'),
    # /crawler/71/download/
    url(r'^(?P<video_id>[0-9]+)/download/$', views.download_video, name='download'),
]